// pages/upload/upload.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imageName:'',
    filePath:'',
    imageRemark:'',
    openID:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const ui = wx.getStorageSync('openID')
    console.log('通过缓存获取到',ui)
      this.setData({
        openID:ui
      })
  },

  getNameValue: function(event) {
    this.setData({
      imageName:event.detail.value
    })
  },

  getRemarksValue: function(e) {
    this.setData({
      imageRemark:e.detail.value
    })
  },

  chooseImage: function (e) {
    const loginToken = wx.getStorageSync('openID')
    if (!loginToken) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      })
      return
    }
    const _this = this;
    wx.chooseImage({
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      count: 1, // 最多选择几张图片
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        console.log(res)
        wx.showToast({
          title: '上传中',
        });
        _this.setData({
          filePath:res.tempFilePaths[0]
        })
      }
    })
  },

  uploadImage: function() {
        let cloudPath = this.data.imageName
        let filePath = this.data.filePath
        if(this.data.imageName == '') {
          wx.showToast({
            title: '请输入图片名',
          })
          return
        }
        if(this.data.filePath == '') {
          wx.showToast({
            title: '请选择一张图片',
          })
          return
        }
        wx.showToast({
          title: '上传中',
        });
        wx.cloud.uploadFile({
          cloudPath: cloudPath, // 上传至云端的路径
          filePath: filePath, // 小程序临时文件路径
          success: res => {
            // 返回文件 ID
            wx.showToast({
              title: '上传成功',
            })
            console.log("上传图片成功",res);
            this.setData({
              bigImg:res.fileID,
            });
            let fileID = res.fileID;
            console.log(this.data.bigImg)
            const db = wx.cloud.database()
            db.collection("images").add({
              data: {
                image_name:this.data.imageName,
                image_src:fileID,
                status:true,
                user_id:'dsada',
                image_remark:this.data.imageRemark,
                openID:this.data.openID
              },
              success: res=> {
                console.log('get success')
                wx.switchTab({
                  url: '../user/user',
                })
              }
            })
          },
          fail: console.error
        })
  }
})