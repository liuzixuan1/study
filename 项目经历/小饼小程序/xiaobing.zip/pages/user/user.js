// pages/user/user.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    openID:'',
    hasUserInfo: false,
    canIUseGetUserProfile: false,
  },

})
Component({
  properties: {},
  data: {
    openID:'',
    userInfo:{},
    bigImg:"",
    args: {
      withCredentials: true,
      lang: 'zh_CN'
    }
  },
  methods: {
    onLoad: function (options) {
      const ui = wx.getAccountInfoSync("userinfo")
      this.setData({
        userInfo:ui,
        openID:ui.gender
      })
    },

    getUserProfile: function() {
      wx.getUserProfile({
        desc: '用于展示头像昵称',
        success: res=>{
          this.setData({
            userInfo:res.userInfo,
          })
          console.log("获取用户昵称成功",res)
          wx.cloud.callFunction({
            name: 'getUserOpenID',
            complete: res => {
              this.setData({
                openID:res.result.openid
              })
              wx.setStorage({
                key:"openID",
                data:res.result.openid
              })     
                wx.showToast({
                  title: '登录成功',
                })
            }
          })
        },
        fail: res=>{
          console.log("获取用户信息失败",res)
        }
        
      })
    },
  }
});