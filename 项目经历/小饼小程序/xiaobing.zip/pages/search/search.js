// pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputValue: '',
    imageData: []

  },
  searchContent:function(event) {
    this.setData({
      inputValue:event.detail.value
    })
  },
  search: function() {
    this.data.imageData = []
    const db = wx.cloud.database();
    db.collection('images').where({
        image_name:db.RegExp({
          regexp:this.data.inputValue,
          options:'i'
        })
    }).get({
      success: res=>{
        this.setData({
          imageData:res.data
        })
        if(res.data == '') {
          wx.showToast({
            title: '暂无此卡',
          })
        }
      },
      fail(res) {
        console.log('query fail!')
      }
    })

  },
  hideInput: function(){
    wx.switchTab({
      url: '../index/index',
    })
  }
})